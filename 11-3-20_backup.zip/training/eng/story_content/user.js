function ExecuteScript(strId)
{
  switch (strId)
  {
      case "662WyKKN4FW":
        Script1();
        break;
      case "6pKsMAELoeF":
        Script2();
        break;
      case "6OwxGH3SwP0":
        Script3();
        break;
      case "6XZcB5QDB8g":
        Script4();
        break;
      case "5YylW4r5DbG":
        Script5();
        break;
      case "6d1IDUSPqv8":
        Script6();
        break;
      case "6aqj4h3Qp7s":
        Script7();
        break;
  }
}

function Script1()
{
  document.body.style.backgroundImage = "url('BG.png')";
document.body.style.backgroundSize = "cover";
}

function Script2()
{
  document.body.style.backgroundImage = "url('BG.png')";
document.body.style.backgroundSize = "cover";
}

function Script3()
{
  document.body.style.backgroundImage = "url('BG.png')";
document.body.style.backgroundSize = "cover";
}

function Script4()
{
  document.body.style.backgroundImage = "url('BG.png')";
document.body.style.backgroundSize = "cover";
}

function Script5()
{
  window.open("mailto:GM-CODEOFHONOR@owens-minor.com");
}

function Script6()
{
  window.open("https://www.omicodeofhonor.com", "_blank");
}

function Script7()
{
  window.open("mailto:GM-CODEOFHONOR@owens-minor.com");
}

